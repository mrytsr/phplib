<?php

$sql_host  = "localhost";
$sql_login = "root";
$sql_passe = "414060";
$sql_dbase = "audistat";
$sql_table = "stats";

?>
